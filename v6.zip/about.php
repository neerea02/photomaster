<?php
    $title = "About";
    require_once "./utils/utils.php";
    include("./views/about.view.php");