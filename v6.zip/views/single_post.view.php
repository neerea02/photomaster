<?php
  include __DIR__ . "/partials/inicio-doc.part.php";
  include __DIR__ . "/partials/nav.part.php";
?>
<!-- Principal Content Start -->
   <div id="single">
     <div class="container">

    <!-- Full Article -->
      <div class="row">
      <h2>Post Title</h2>
      <hr class="subtitle">
      <div class=" block1">
      <div class="col-xs-12 col-sm-9">
        <p>Nam luctus nunc ut orci posuere ultricies. Donec id ante nec nunc laoreet vestibulum. Nulla in tortor non risus pharetra suscipit. Suspendisse nec diam gravida, scelerisque magna eget, dignissim enim. Sed eget diam facilisis justo elementum aliquet quis ut felis. Vestibulum sus cipit nibh consectetur massa volutpat, vel euismod lectus blandit. 
        </p>
        <p>Minima, earum fuga maiores unde quod quae aspernatur magnam quis adipisci ipsum maxime iusto quidem? Recusandae dolore ipsam eius alias quidem. Dignissimos, recusandae, saepe, omnis, non totam vero unde mollitia natus aliquam magni qui quibusdam incidunt ea nihil error facere ut libero blanditiis accusamus quasi facilis animi repellat consequuntur in sit rerum atque voluptatibus ipsa ullam voluptatum laborum praesentium nesciunt est iusto nulla earum ab tenetur!
        </p>
        <p>Aliquam elementum varius adipiscing. Phasellus vulputate arcu eu scelerisque egestas. Duis lacinia, tellus sed congue porta, tortor felis ornare mi, in eleifend dolor odio ac lacus. Curabitur id nisi ornare, viverra lorem sed, viverra ligula. Donec eu nibh tempus, semper velit sit amet, blandit odio. Phasellus id condimentum sapien, sit amet venenatis sem. 
        </p>
        <p>Quod soluta corrupti earum officia vel inventore vitae quidem, consequuntur odit impedit, eaque dolorem odio praesentium iusto amet voluptatum distinctio iste dicta maiores doloremque porro. Ipsa doloremque illum animi laborum quo in nemo delectus veritatis, amet numquam doloribus a iure sequi nobis vero facere necessitatibus ipsam
        </p>
        <h4>- By Facere</h4>
        <hr>
        <ul class="list-inline">
          <li>6 December |</li>
          <li><a class="page-scroll" href="#form">COMMENT</a> |</li>
          <li><a href="">LIKE</a></li>
        </ul>
      </div>
      <div class="col-xs-12 col-sm-3">
        <h4>Recent Post</h4>
        <hr class="subtitle1">
        <div class="new new1">
        <hr>
           <a href="">Aliquam soluta</a>
           <h5> By <span>Quae</span></h5>
           <p>10 April</p><i class="fa fa-clock-o sr-icons"></i>  8:00 AM
        <hr>
        </div>
        <div class="new">
        <hr>
            <a href="">Consequuntur</a>
           <h5> By <span>Omnis</span></h5>
           <p>12 May</p><i class="fa fa-clock-o sr-icons"></i>  4:00 PM
           <hr>
        </div>
      </div>
      </div>
      </div>
    <!-- End of Full Article -->

    <!-- Comments -->
      <div class="row">
      <div class="col-xs-12 col-sm-12 block2">
        <div class="comment">
          <h4>Young Papou</h4>
          <span>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
          </span>
          <p class="time">9:00 AM</p>
          <hr>
          <p>Perferendis recusandae consequuntur quasi, non culpa. Minus porro officiis veniam facilis praesentium expedita doloribus, recusandae aut dolore autem, modi consequuntur rem perferendis dolores quisquam, sequi quas. Esse, doloremque consectetur veniam quo ut voluptas necessitatibus quae quis iusto quod optio eligendi distinctio dicta, nihil impedit officia aspernatur tenetur saepe expedita, odio vitae reprehenderit pariatur!</p>
        </div>
        <div class="comment alt-comment">
          <h4>Tom Junky</h4>
          <span>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star-o sr-icons"></i>
          </span>
          <p class="time">5:00 AM</p>
          <hr>
          <p>In felis ante, aliquet sit amet venenatis at, feugiat sed leo. Fusce pretium, velit in luctus ornare, elit lorem ultrices tortor, sed consectetur orci risus mollis ante. Cras ut aliquam nulla. Aliquam convallis sapien quis cursus condimentum.Nunc sit amet dapibus est, sit amet varius risus. Donec luctus lacinia mauris, at feugiat ligula facilisis ac. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed id ligula consectetur.</p>
        </div>
        <div class="comment">
          <h4>John Dark</h4>
          <span>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star sr-icons"></i>
            <i class="fa fa-star-o sr-icons"></i>
            <i class="fa fa-star-o sr-icons"></i>
          </span>
          <p class="time">9:00 AM</p>
          <hr>
          <p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed id ligula consectetur, iaculis dolor vitae, gravida mauris. Duis ultrices tortor non felis convallis bibendum. Maecenas diam velit, sollicitudin at imperdiet ac, consectetur non nibh. Etiam eget dapibus nulla. Nulla placerat mauris ut elit placerat luctus. Aliquam porttitor leo non nisl scelerisque sollicitudin. </p>
        </div>
          <hr class="line">
          <div id="form" class="col-xs-12 col-sm-6 col-sm-push-3">
          <form class="form-horizontal">
            <div class="form-group">
              <div class="col-xs-12 col-sm-6">
                <label class="label-control">Name</label>
                <input type="text" class="form-control">
              </div>
              <div class="col-xs-12 col-sm-6">
                <label class="label-control">Email</label>
                <input type="text" class="form-control">
              </div>
            </div>
            <div class="form-group">
              <div class="col-xs-12">
                  <label class="label-control">Type Your Comment</label>
                <textarea class="form-control"></textarea>
                <a href="" class="btn btn-lg btn-info sr-button">SEND</a>
              </div>
            </div>
          </form>
          </div>
      </div>
      </div>
    <!-- End of Comments -->  
     </div>
   </div>
<!-- End of Principal Content Start -->

   <!-- Footer -->
   <footer>
     <div class="container text-muted text-center">
         <ul class="list-inline social-buttons">
            <li><a href="#"><i class="fa fa-facebook sr-icons"></i></a>
            </li>
            <li><a href="#"><i class="fa fa-twitter sr-icons"></i></a>
            </li>
            <li><a href="#"><i class="fa fa-google-plus sr-icons"></i></a>
            </li>
         </ul>
         <ul class="list-inline">
           <li class="footer-number"><i class="fa fa-phone sr-icons"></i>  (00228)92229954 </li>
           <li><i class="fa fa-envelope sr-icons"></i>  kouvenceslas93@gmail.com</li>
         </ul>
         <p>Photography Fanatic Template &copy; 2017</p>
     </div>
   </footer>

<?php
  include __DIR__ . "/partials/fin-doc.part.php";
?>