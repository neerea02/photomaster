<?php
    $title = "Single post";
    require_once "./utils/utils.php";
    include("./views/single_post.view.php");