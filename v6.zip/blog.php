<?php
    $title = "Blog";
    require_once "./utils/utils.php";
    include("./views/blog.view.php");